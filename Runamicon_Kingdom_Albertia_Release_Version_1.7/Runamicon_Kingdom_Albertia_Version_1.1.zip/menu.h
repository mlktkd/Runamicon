#pragma once
#include "includes.h"
#include "Coord.h"

using namespace sf;

class Menu
{
  Texture MenuTexture;
  Sprite MenuSprite;
  Font textFont;
  std::vector<Text> menu;
  Coord Pos;
  Color fillColor;
  Color SelectedColor;
  int selection;

  void prepareMenu();

  void virtual Init(int Type);
public:

  Menu(int Type);

  int virtual StartMenu(RenderWindow& window);

  void selectionDown();

  void selectionUp();
};
