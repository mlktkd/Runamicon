#include "Enemy.h"

Enemy::Enemy() : enmHitBox(), speed(), radiusFOV(), LivingEntity(), dir(Diraction::right) {}

void Enemy::SetPos(Coord pos) {
  Pos = pos;
  sprite.setPosition(Pos.x, Pos.y);
}

void Enemy::SetState(State state, float CurrTime) {
  oldState = currentState;
  currentState = state;
  if (GetCurrDir() == Diraction::left) { SetNewTileSetLeft(); }
  else if (GetCurrDir() == Diraction::right) { SetNewTileSetRight(); }
  if (currentState == State::standing) { spriteAnim.SetNextFrame(sprite, CurrTime); }
}

State Enemy::GetCurrState() const { return currentState; }

bool Enemy::isPlInFieldOfView(Player& pl) {  //������� ����� ��������
  return int(sqrt(((pl.GetPos().x - this->Pos.x) * (pl.GetPos().x - this->Pos.x)) + ((pl.GetPos().y - this->Pos.y) * (pl.GetPos().y - this->Pos.y)))) <= radiusFOV;
}

void Enemy::Move(Player& pl, Map& map, float CurrTime) { //�����
  int diff_x, diff_y;
  Coord oldPos = Pos;
  if (pl.GetHitBoxCenterPos().x > this->GetHitBoxCenterPos().x) { diff_x = pl.GetHitBoxCenterPos().x - this->GetHitBoxCenterPos().x; oldDiraction = currentDiraction; currentDiraction = Diraction::right; } 
  else if (pl.GetHitBoxCenterPos().x < this->GetHitBoxCenterPos().x) { diff_x = this->GetHitBoxCenterPos().x - pl.GetHitBoxCenterPos().x; oldDiraction = currentDiraction; currentDiraction = Diraction::left; } 
  else { diff_x = 0; }
  if (pl.GetHitBoxCenterPos().y > this->GetHitBoxCenterPos().y) { diff_y = pl.GetHitBoxCenterPos().y - this->GetHitBoxCenterPos().y; } 
  else if (pl.GetHitBoxCenterPos().y < this->GetHitBoxCenterPos().y) { diff_y = this->GetHitBoxCenterPos().y - pl.GetHitBoxCenterPos().y; } 
  else { diff_y = 0; }
  extern float GlobalSpeed;

  if ((diff_x <= TILESIZE * 2 && diff_y <= TILESIZE * 2)) {
    if (pl.GetHitBoxCenterPos().y > this->GetHitBoxCenterPos().y) {
      Pos.y += speed * GlobalSpeed;
      dir = down;
    }
    if (pl.GetHitBoxCenterPos().y < this->GetHitBoxCenterPos().y) {
      Pos.y -= speed * GlobalSpeed;
      dir = up;
    }
    if (diff_x <= TILESIZE * 2 && diff_y <= 5) {
      SetState(State::atacking, CurrTime);
      if (spriteAnim.GetCurrFrameNum() == spriteAnim.GetAmountFrames() - 1) {
        //Atack(pl);
      }
    }
  } else if (diff_x > diff_y) {
    if (pl.GetHitBoxCenterPos().x > this->GetHitBoxCenterPos().x) {
      Pos.x += speed * GlobalSpeed;
      dir = Diraction::right;
      if (oldDiraction != currentDiraction) { SetNewTileSetRight(); }
    }
    if (pl.GetHitBoxCenterPos().x < this->GetHitBoxCenterPos().x) {
      Pos.x -= speed * GlobalSpeed;
      dir = Diraction::left;
      if (oldDiraction != currentDiraction) { SetNewTileSetLeft(); }
    }
  } else {
    if (pl.GetHitBoxCenterPos().y > this->GetHitBoxCenterPos().y) {
      Pos.y += speed * GlobalSpeed;
      dir = Diraction::down;
    }
    if (pl.GetHitBoxCenterPos().y < this->GetHitBoxCenterPos().y) {
      Pos.y -= speed * GlobalSpeed;
      dir = Diraction::up;
    }
  }
  spriteAnim.SetNextFrame(sprite, CurrTime);
  Collision(map); // �������� �� ����������� �� ������
}

void Enemy::Atack(Player& pl) {
  if (this->currentState == State::atacking && pl.GetCurrState() != State::blocking) {
    pl.MinusHealth(this->Damage);
  }
}

void Enemy::Collision(Map& map) {
  for (size_t i = (Pos.y + enmHitBox.y) / TILESIZE; i < (Pos.y + enmHitBox.y + enmHitBox.height) / TILESIZE; i++) {
    for (size_t j = (Pos.x + enmHitBox.x) / TILESIZE; j < (Pos.x + enmHitBox.x + enmHitBox.width) / TILESIZE; j++) {

      if (map.CurrentMap[i][j] == 'O') {
        switch (dir) {
        case Diraction::right:
          Pos.x = j * TILESIZE - enmHitBox.x - enmHitBox.width;
          break;
        case Diraction::left:
          Pos.x = j * TILESIZE - enmHitBox.x + TILESIZE;
          return;
          break;
        case Diraction::up:
          Pos.y = i * TILESIZE - enmHitBox.y + TILESIZE;
          break;
        case Diraction::down:
          Pos.y = i * TILESIZE - enmHitBox.height - enmHitBox.y;
          break;
        }
      }
      else if (map.CurrentMap[i][j] == 'N') {
        map.SetNextMap();
        Pos = map.GetSpownPoint();
        return;
      }
      else if (map.CurrentMap[i][j] == 'P') {
        map.SetPreviousMap();
        Pos = map.GetSpownPoint();
        return;
      }
    }
  }
}

void Enemy::UpdateSpritePos() {
  sprite.setPosition(Pos.x, Pos.y);
  enmHitBox.box.setPosition(Pos.x + enmHitBox.x, Pos.y + enmHitBox.y);
}

Coord Enemy::GetPos()const { return Pos; }

Coord Enemy::GetHitBoxCenterPos() const { return Coord(Pos.x + enmHitBox.x + (enmHitBox.width / 2), Pos.y + enmHitBox.y + (enmHitBox.height / 2)); }

void Enemy::Draw(RenderWindow& window) { // ���������� ���������
  if (currentState == walking) { UpdateSpritePos(); }
  window.draw(sprite);
  window.draw(enmHitBox.box); // ���������� ��������� ��� // ������������� ���� ������� ������ ������ ���������
}

Box Enemy::GetHitBox()const {
  Box temp(enmHitBox.x + Pos.x, enmHitBox.y + Pos.y, enmHitBox.height, enmHitBox.width);
  return temp;
}

Enemy::~Enemy() {}

// ------------------------------------------------------------------------------------------------------------------------------//

Wolf::Wolf() { Init(); }

void Wolf::Init() {
  spriteAnim.Init(sprite, "wolf_sprites.png", 1, WolfStandingLeft);
  currentDiraction = Diraction::left;
  oldDiraction = Diraction::right;
  currentState = standing;
  oldState = walking;
  health = 50;
  Damage = 5;
  speed = 7;
  isAlive = true;
  isInvincible = false;
  radiusFOV = 400;
  Pos = Coord(300, 600);
  enmHitBox = HitBox(20, 27, 10, 45);
  sprite.setPosition(Pos.x, Pos.y);
  sprite.scale(0.7f, 0.7f);
  enmHitBox.box.setFillColor(Color(0, 100, 0, 100));
}

void Wolf::SetNewTileSetLeft() {
  switch (currentState) {
  case standing: spriteAnim.SetArrImg(1, WolfStandingLeft); break;
  case walking: spriteAnim.SetArrImg(6, WolfWalkingLeft); break;
  case atacking: spriteAnim.SetArrImg(3, WolfAtackingLeft); break;
  case dying: spriteAnim.SetArrImg(7, WolfDyingLeft); break;
  }
}

void Wolf::SetNewTileSetRight() {
  switch (currentState) {
  case standing: spriteAnim.SetArrImg(1, WolfStandingRight); break;
  case walking: spriteAnim.SetArrImg(6, WolfWalkingRight); break;
  case atacking: spriteAnim.SetArrImg(3, WolfAtackingRight); break;
  case dying: spriteAnim.SetArrImg(7, WolfDyingRight); break;
  }
}