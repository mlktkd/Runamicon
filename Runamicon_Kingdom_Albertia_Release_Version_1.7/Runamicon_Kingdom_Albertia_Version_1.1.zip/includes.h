#pragma once
#include <SFML/Graphics.hpp> 
#include <iostream>
#include <string>
#include <vector>
#include <iterator>
#include <algorithm>
#include <math.h>
using namespace sf;

#define TILESIZE 32
#define AMOUNTWOLVES 10

//���������� ������ �� �������� ������
// Knight (������� �������3,k=])
#define PlStandingRight new Frames[1]{ {Coord(0, 120), 120, 120} }
#define PlWalkingRight new Frames[6]{ {Coord(120, 120), 120,120}, {Coord(240, 120), 120,120}, {Coord(360, 120), 120,120}, {Coord(480, 120), 120,120}, {Coord(600, 120), 120,120}, {Coord(720, 120), 120,120}}
#define PlBlockingRight new Frames[1]{ {Coord(0, 360), 120,120} }
#define PlAtackingRight new Frames[3]{ {Coord(120, 360), 120,120}, {Coord(240, 360), 120,120}, {Coord(360, 360), 120,120} }

#define PlStandingLeft new Frames[1]{ {Coord(0, 0), 120, 120} }
#define PlWalkingLeft new Frames[6]{ {Coord(120, 0), 120,120}, {Coord(240, 0), 120,120}, {Coord(360, 0), 120,120}, {Coord(480, 0), 120,120}, {Coord(600, 0), 120,120}, {Coord(720, 0), 120,120} }
#define PlBlockingLeft new Frames[1]{ {Coord(0, 240), 120,120} }
#define PlAtackingLeft new Frames[3]{ {Coord(120, 240), 120,120}, {Coord(240, 240), 120,120}, {Coord(360, 240), 120,120} }

// Wolf
#define WolfStandingRight new Frames[1]{{Coord(27, 25), 63, 76}}
#define WolfWalkingRight new Frames[6]{ {Coord(27, 165), 56, 94}, {Coord(122, 165), 56, 105}, {Coord(231, 165), 56, 107}, {Coord(343, 165), 56, 107}, {Coord(461, 165), 56, 95}, {Coord(564, 165), 56, 94}}
#define WolfAtackingRight new Frames[3]{ {Coord(26, 226), 86, 90}, {Coord(119, 226), 86, 81}, {Coord(200, 226), 86, 90}}
#define WolfDyingRight new Frames[7]{ {Coord(25, 471), 91, 63}, {Coord(99, 471), 91, 50}, {Coord(154, 471), 91, 60}, {Coord(221, 499), 62, 92}, {Coord(318, 513), 49, 93}, {Coord(418, 535), 27, 94}, {Coord(520, 535), 27, 91}}

#define WolfStandingLeft new Frames[1]{{Coord(103, 25), 63, -76}}
#define WolfWalkingLeft new Frames[6]{ {Coord(121, 165), 56, -94}, {Coord(227, 165), 56, -105}, {Coord(338, 165), 56, -107}, {Coord(450, 165), 56, -107}, {Coord(556, 165), 56, -95}, {Coord(658, 165), 56, -94}}
#define WolfAtackingLeft new Frames[3]{ {Coord(116, 226), 86, -90}, {Coord(200, 226), 86, -81}, {Coord(290, 226), 86, -90}}
#define WolfDyingLeft new Frames[7]{ {Coord(88, 471), 91, -63}, {Coord(149, 471), 91, -50}, {Coord(214, 471), 91, -60}, {Coord(313, 499), 62, -92}, {Coord(411, 513), 49, -93}, {Coord(512, 535), 27, -94}, {Coord(611, 535), 27, -91}}



enum Diraction {
  right, left, up,down, Max_Dir
};

enum State {
  standing, walking, blocking, atacking, dying
};