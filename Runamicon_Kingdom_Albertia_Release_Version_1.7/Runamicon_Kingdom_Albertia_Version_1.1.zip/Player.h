#pragma once
#include "includes.h"
#include "HitBox.h"
#include "Entity.h"

static class Wolf;

class Player :public virtual LivingEntity {
protected:
  HitBox plHitBox;
  int speed;
  DamageBox Db;
public:
  Player();

  virtual void Init() = 0;

  virtual void SetNewTileSetRight() = 0;

  virtual void SetNewTileSetLeft() = 0;
  
  virtual void SetNewState(State newState);

  virtual HitBox GetHB() const;

  virtual void Attack(Wolf wolves[AMOUNTWOLVES]);

  virtual void Move(Diraction newDirection, State newState, RenderWindow& window, Map& map, float CurrTime);

  virtual void Collision(Map& map);

  virtual void UpdateSpritePos();

  virtual Coord GetPos()const;

  virtual Coord GetHitBoxCenterPos() const;

  virtual void Draw(RenderWindow& window);

  //����� �������������� �� ����������
  bool Interract(Box obj);

  virtual ~Player();
};

class PlayerKnight:public virtual Player
{
protected:
public:
  PlayerKnight();

  virtual void Init();

  virtual void SetNewTileSetLeft();

  virtual void SetNewTileSetRight();

  virtual void Draw(RenderWindow& window);
};

class PlayerFairy :public virtual Player {
protected:
public:
  PlayerFairy();

  virtual void Init();

  virtual void SetNewTileSetLeft();

  virtual void SetNewTileSetRight();
};

