#pragma once
#include "includes.h"
#include "menu.h"
#include "Enemy.h"

class Game
{
  RenderWindow window; 
  Menu mainMenu;
  Map map;
  PlayerKnight player;
  PlayerFairy plFairy;
  //vector<Wolf> wolves;
  Wolf wolves[AMOUNTWOLVES];
  float CurrTime;
public:
  Game();

  void Start();

  void StartGame();

  void SetCenter(View& view, float x, float y);

  void MoveEntities();

  void DrawEntities();
};

