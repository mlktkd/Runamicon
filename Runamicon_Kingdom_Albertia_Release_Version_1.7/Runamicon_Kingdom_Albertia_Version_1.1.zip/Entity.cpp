#include "Entity.h"

Entity::Entity() :Pos(), health(), isAlive(true), isInvincible(), sprite(), spriteAnim(), Damage() {}

Entity::Entity(Coord Pos, int health, int Damage, string FileName, int AmountFrames, Frames * ArrImg, bool isAlive, bool isInvincible)
:Pos(Pos), health(health), Damage(Damage), spriteAnim(sprite, FileName, AmountFrames, ArrImg), isAlive(isAlive), isInvincible(isInvincible) {}

const ImageAnimation& Entity::GetSpriteAnim() const { return spriteAnim; }

bool Entity::GetIsInvincible() const { return isInvincible; }

bool Entity::GetIsAlive() const { return isAlive; }

float Entity::GetDamageVal()const { return Damage; }

inline Entity::~Entity() {}

//-----------------------------------------------------------------------------------//

LivingEntity::LivingEntity() : Entity(), currentDiraction(), oldDiraction(), currentState(), oldState() {}

LivingEntity::LivingEntity(Diraction currentDiraction, Diraction oldDiraction, State currentState, State oldState, Coord Pos, int health, int Damage, string FileName, int AmountFrames, Frames* ArrImg, bool isAlive, bool isInvincible)
:Entity(Pos, health, Damage, FileName, AmountFrames, ArrImg, isAlive, isInvincible), currentDiraction(currentDiraction), oldDiraction(oldDiraction), currentState(currentState), oldState(oldState) { }

Diraction LivingEntity::GetOldDir() const { return oldDiraction; }

Diraction LivingEntity::GetCurrDir() const { return currentDiraction; }

State LivingEntity::GetCurrState() const { return currentState; }

State LivingEntity::GetOldState() const { return oldState; }

void LivingEntity::MinusHealth(float val) {
  health -= val;
  if (health <= 0 && isInvincible != true) { isAlive = false; }
}

LivingEntity::~LivingEntity() {}