#pragma once
#include <SFML/Graphics.hpp>
#include "Coord.h"
#include "ImageAnimation.h"
using namespace sf;

enum Diraction;
enum State;

// ��� ������� ������

class Entity {
protected:
  Coord Pos;
  int health;
  bool isAlive;
  bool isInvincible;
  Sprite sprite;
  ImageAnimation spriteAnim;
  float Damage;
public:
  Entity();

  Entity(Coord Pos, int health, int Damage, string FileName, int AmountFrames, Frames* ArrImg, bool isAlive = true, bool isInvincible = false);

  const ImageAnimation& GetSpriteAnim() const;

  bool GetIsInvincible() const;

  bool GetIsAlive() const;

  float GetDamageVal()const;

  virtual ~Entity() = 0;
};

class LivingEntity :public virtual Entity {
protected:
  Diraction currentDiraction;
  Diraction oldDiraction;
  State currentState;
  State oldState;
public:
  LivingEntity();
  LivingEntity(Diraction currentDiraction, Diraction oldDiraction, State currentState, State oldState, Coord Pos,
    int health, int Damage, string FileName, int AmountFrames, Frames* ArrImg, bool isAlive = true, bool isInvincible = false);

  Diraction GetOldDir() const;

  Diraction GetCurrDir() const;

  State GetCurrState() const;

  State GetOldState() const;

  virtual void MinusHealth(float val);

  virtual ~LivingEntity();
};