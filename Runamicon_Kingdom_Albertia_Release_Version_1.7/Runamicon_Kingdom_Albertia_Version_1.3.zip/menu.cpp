#include "menu.h"

extern GlobalFont globalFont;

void Menu::prepareMenu() {
  for (size_t i = 0; i < menu.size(); i++)
  {
    menu[i].setFont(globalFont());
    menu[i].setPosition(Pos.x, Pos.y + (40 * i));
    menu[i].setFillColor(fillColor);
  }
  menu[0].setFillColor(SelectedColor);
}

void Menu::Init(int Type) {
  MenuTexture.loadFromFile("fon.png");
  MenuSprite.setTexture(MenuTexture);
  fillColor = Color(160, 20, 60);
  SelectedColor = Color(60, 20, 160);
  Pos.x = 400;
  Pos.y = 200;
  switch (Type) {
  default:
  case 0: //������������� �������� ����
    menu.resize(5);
    menu[0].setString("StartGame");
    menu[1].setString("Setting");
    menu[2].setString("Help");
    menu[3].setString("Credits");
    menu[4].setString("Exit");
    prepareMenu();
    break;
  }
}

Menu::Menu(int Type) :selection() {
  Init(Type); 
}

int Menu::StartMenu(RenderWindow& window) {

  View MenuView;
  MenuView.setSize(window.getSize().x, window.getSize().y);
  MenuView.setCenter(window.getSize().x / 2, window.getSize().y / 2);
  window.setView(MenuView);

  Event menuEvent;
  while (true) {
    while (window.pollEvent(menuEvent))
    {
      if (menuEvent.type == Event::Closed) {
        window.close();
        return 4;
      }
      if (menuEvent.type == Event::KeyReleased) {
        switch (menuEvent.key.code)
        {
        case Keyboard::Up:
          selectionUp();
          break;
        case Keyboard::Down:
          selectionDown();
          break;
        case Keyboard::Left:
          break;
        case Keyboard::Right:
          break;
        case Keyboard::Enter:
          window.clear();
          return selection;
          break;
        default:
          break;
        }
      }
    }
    window.draw(MenuSprite);
    for (size_t i = 0; i < menu.size(); i++)
    {
      window.draw(menu[i]);
    }

    window.display();
    window.clear();
  }
}

void Menu::selectionDown() {
  menu[selection].setFillColor(fillColor);
  if (selection >= menu.size() - 1) selection = 0;
  else ++selection;
  menu[selection].setFillColor(SelectedColor);
}

void Menu::selectionUp() {
  menu[selection].setFillColor(fillColor);
  if (!selection || selection < 0) selection = menu.size() - 1;
  else --selection;
  menu[selection].setFillColor(SelectedColor);
}