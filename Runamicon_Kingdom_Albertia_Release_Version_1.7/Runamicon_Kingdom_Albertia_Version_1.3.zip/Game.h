#pragma once
#include "includes.h"
#include "menu.h"
#include "Enemy.h"
#include "Travaler.h"
#include "Potion.h"

class Game
{
  RenderWindow window; 
  Menu mainMenu;
  Map map;
  PlayerKnight player;
  //PlayerFairy plFairy;
  Travaler travaler;
  Wolf wolves[AMOUNTWOLVES];
  Skeleton skeleton[AMOUNTSKELKETONES];
  Slime slime[AMOUNTSLIME];
  HitBox SafeZone[AMOUNTSAFEZONES];
  float CurrTime;
  list<Potion> potions;
  list<Potion> desertPotions;
public:
  Game();

  void Start();

  void StartGame();

  void SetCenter(View& view, float x, float y);

  void MoveEntities(); 

  void PickUpPotions(list<Potion>& LPotion);

  void DrawEntities();

  bool SafeZoneInteraction();
};

