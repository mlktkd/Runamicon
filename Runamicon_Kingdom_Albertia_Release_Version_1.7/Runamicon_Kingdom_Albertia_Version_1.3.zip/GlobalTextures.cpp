#include "GlobalTextures.h"

GlobalTextures::GlobalTextures(int num)
{
  Init(num);
}

void GlobalTextures::Init(int num)
{
  switch (num) {
  default:
  case 0://wolf
    texture.loadFromFile("wolf_sprites.png");
    break;
  case 1://Skeleton
    texture.loadFromFile("Skeleton_Tileset.png");
    break;
  case 2:
    texture.loadFromFile("slime-Sheet.png");
    break;
  }
}

Texture& GlobalTextures::operator()() {
  return texture;
}