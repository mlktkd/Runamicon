#include "GlobalItemTexture.h"

GlobalItemTexture::GlobalItemTexture()
{
  texture.loadFromFile("Items.png");
}

Texture& GlobalItemTexture::operator()() {
  return texture;
}