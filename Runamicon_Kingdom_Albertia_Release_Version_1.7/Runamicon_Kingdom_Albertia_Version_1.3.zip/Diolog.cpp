#include "Diolog.h"

extern GlobalFont globalFont;

LineNode::LineNode() : line(), nextLines(), answer(), Choice() {}

size_t LineNode::size() { return nextLines.size(); }

String& LineNode::operator[](int i) {
  return answer[i]; // ��������� ������ �� �������
}

LineNode* LineNode::getNext() { return nextLines[Choice]; } // ��� ������ �� �������

void LineNode::ChoiceUp() {
  if (!Choice)Choice = size() - 1;
  else Choice--;
}

void LineNode::ChoiceDown() {
  if (Choice == size() - 1)Choice = 0;
  else Choice++;
}

LineNode::~LineNode() {} // ���������� ������ �� ������ ��� ��� ������ ��� ���� ������� �� ������

// -------------------------------------------------------------------------------------- //

Diolog::Diolog() :lineSet(), startOfDialog(), currentStart(), badEnd(), goodEnd(), isDiologActive(), isCanTalk(true), CurrentLineNode() {
  Init();
  CurrentLineNode = startOfDialog[currentStart];
  text.setFont(globalFont());
  fillColor = Color(160, 20, 60);
  selectedColor = Color(237, 241, 165);
  text.scale(Vector2f(0.3,0.3));
}

void Diolog::Init() {
  lineSet.push_back(new LineNode()); //0
  lineSet[0]->line = "Hello, dear Knight! I mean no harm, please lower your sword.";
  lineSet[0]->answer.push_back("Hello for you too!");
  lineSet[0]->answer.push_back("Who are you? I don't trust strangers, \nand what are you doing in such a dangerows place?");
  lineSet[0]->answer.push_back("GoodBye");
  lineSet.push_back(new LineNode());//1
  lineSet[1]->line = "You may be curious why i am here and who i am.\n But trust me i'm harmless, i just travel across the world.";
  lineSet[1]->answer.push_back("...");
  lineSet.push_back(new LineNode());//2
  lineSet[2]->line = "...";
  lineSet[2]->answer.push_back("How did you get here ?");
  lineSet[2]->answer.push_back("Do you know anything about Meridius Graybeard");
  lineSet[2]->answer.push_back("Do you mind Trading a few thigs?");
  lineSet[2]->answer.push_back("Ok Goodbye then");
  lineSet.push_back(new LineNode());//3
  lineSet[3]->line = "It's a long story. \nI've been chased by evil creatures and they left when i got here. \nThis oasis must contain some protective magic against evil creatures.";
  lineSet[3]->answer.push_back("...");
  lineSet.push_back(new LineNode());//4
  lineSet[4]->line = "Oh that odd mage... Yeah i've stumbled across with him a couple times. \nHe is experiensed travaler you know. \nBut this is the only thing i know. \nI've got something related to him, and if you want to we can trade.";
  lineSet[4]->answer.push_back("...");
  lineSet.push_back(new LineNode());//5
  lineSet[5]->line = "Ok here is what i got...";
  lineSet[5]->answer.push_back("...");
  lineSet.push_back(new LineNode());//6
  lineSet[6]->line = "See you later...";
  lineSet[6]->answer.push_back("...");
  lineSet.push_back(new LineNode());//7
  lineSet[7]->line = "good end";
  lineSet[7]->answer.push_back("...");
  lineSet.push_back(new LineNode());//8
  lineSet[8]->line = "bad end";
  lineSet[8]->answer.push_back("...");
  startOfDialog.push_back(lineSet[0]);
  startOfDialog.push_back(lineSet[2]);
  currentStart = 0;
  badEnd = lineSet[8];
  goodEnd = lineSet[7];
  lineSet[0]->nextLines.push_back(lineSet[1]);
  lineSet[0]->nextLines.push_back(lineSet[1]);
  lineSet[0]->nextLines.push_back(lineSet[6]);
  lineSet[1]->nextLines.push_back(lineSet[2]);
  lineSet[2]->nextLines.push_back(lineSet[3]);
  lineSet[2]->nextLines.push_back(lineSet[4]);
  lineSet[2]->nextLines.push_back(lineSet[5]);
  lineSet[2]->nextLines.push_back(lineSet[6]);
  lineSet[3]->nextLines.push_back(lineSet[2]);
  lineSet[4]->nextLines.push_back(lineSet[2]);
  lineSet[6]->nextLines.push_back(lineSet[8]);
  lineSet[5]->nextLines.push_back(lineSet[7]);
}

bool Diolog::GetIsCanTalk()const {return isCanTalk;}

bool Diolog::GetIsDiologActive()const {return isDiologActive;}

void Diolog::SetIsDiologAcitve(bool isActive) {
  isDiologActive = isActive;
}

void Diolog::newDiolog() {
  CurrentLineNode = startOfDialog[currentStart];
}

void Diolog::startDiolog(RenderWindow& window) {

  if (CurrentLineNode == badEnd) {
    currentStart = 1;
    isDiologActive = false;
  }
  else if (CurrentLineNode == goodEnd) {
    currentStart = 1;
    isDiologActive = false;
  }

  Event event;

  // draw question
  // draw ans

  while (window.pollEvent(event)) {
    if (event.type == Event::KeyReleased) {
      switch (event.key.code)
      {
      case Keyboard::Up:
        CurrentLineNode->ChoiceUp();
        break;
      case Keyboard::Down:
        CurrentLineNode->ChoiceDown();
        break;
      case Keyboard::Enter:
        CurrentLineNode = CurrentLineNode->getNext();
        break;
      default:
        break;
      }
    }
  }
}

void Diolog::Fill(std::string fileName) {

}//�������� ������� � ����� (��������)

void Diolog::Draw(RenderWindow& window) {
  RectangleShape background;
  Vector2f temp(window.getView().getCenter());
  temp.x -= (window.getView().getSize().x / 2)-20;
  temp.y -= 40;
  background.setPosition(Vector2f(temp.x-20, temp.y-30));
  background.setSize(window.getView().getSize());
  background.setFillColor(Color(1, 1, 1, 200));
  window.draw(background);
  text.setString(CurrentLineNode->line);
  text.setPosition(temp);
  text.setFillColor(fillColor);
  window.draw(text);
  for (size_t i = 0; i < CurrentLineNode->size(); i++)
  {
    text.setString(CurrentLineNode->answer[i]);
    text.setPosition(Vector2f(temp.x, temp.y+((i+2)*30)));
    if (CurrentLineNode->Choice == i) {
      text.setFillColor(selectedColor);
    }
    else {
      text.setFillColor(fillColor);
    }
    window.draw(text);
  }
}


Diolog::~Diolog() {
  for (size_t i = 0; i < lineSet.size(); i++)
  {
    delete lineSet[i];
  }
}