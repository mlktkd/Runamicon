#pragma once
#include "Entity.h"
#include "GlobalItemTexture.h"

class Potion : public virtual Entity
{
  Text text;
  float healthRegen;
  int cnt;
public:
  Potion();

  Potion(Coord pos);

  void Draw(RenderWindow&window);

  void AddPotion();

  bool Use();

  void SetCnt(int val);

  void UpdatePotionBar(RenderWindow&window);

  Box GetHitBox();

  float GetHealingPower()const;

  int GetCnt()const;

  ~Potion();
};