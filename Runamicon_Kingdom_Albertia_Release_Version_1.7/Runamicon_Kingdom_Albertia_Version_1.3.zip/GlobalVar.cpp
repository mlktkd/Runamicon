#pragma once
#include "GlobalItemTexture.h"
#include "GlobalFont.h"
#include "GlobalTextures.h"

GlobalFont::GlobalFont() {
  font.loadFromFile("pixel_pirate.ttf");
}

Font&  GlobalFont::operator()() {
  return font;
}

struct LC { LC() { srand(time(NULL)); } }_;

GlobalFont globalFont;

float GlobalAnimationSpeed = 0.08f;

float GlobalSpeed = 0.8f;

GlobalItemTexture globalItemTexture;

GlobalTextures Twolf(0);

GlobalTextures Tskeleton(1);

GlobalTextures Tslime(2);